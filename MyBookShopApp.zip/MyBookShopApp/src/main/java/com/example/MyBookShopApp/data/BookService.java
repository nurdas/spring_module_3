package com.example.MyBookShopApp.data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@Service
public class BookService {
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public BookService(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Book> getBookData(String condition) {
        String sql = "SELECT b.id,title,a.author,priceOld,price FROM books b JOIN AUTHORS a ON a.ID = b.author";

        switch (condition) {
            case ("n"):     // new
                sql = sql + " ORDER BY date_issue DESC";
                break;
            case ("p"):     // popular
                sql = sql + " WHERE sold_count > 0 ORDER BY sold_count DESC";
                break;
            case ("r"):     // recommended
                sql = sql + " ORDER BY recommend_priority ASC";
                break;
        }

        List<Book> books = jdbcTemplate.query(sql, (ResultSet rs, int rowNum) -> {
            Book book = new Book();
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setAuthor(rs.getString("author"));
            book.setPriceOld(rs.getString("priceOld"));
            book.setPrice(rs.getString("price"));
            return book;
        });
        return new ArrayList<>(books);
    }

    public List<Book> getBookDataPopular() {
        List<Book> books = jdbcTemplate.query("SELECT id,title,author,priceOld,price FROM books WHERE sold_count > 0 ORDER BY sold_count DESC", (ResultSet rs, int rowNum) -> {
            Book book = new Book();
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setAuthor(rs.getString("author"));
            book.setPriceOld(rs.getString("priceOld"));
            book.setPrice(rs.getString("price"));
            return book;
        });
        return new ArrayList<>(books);
    }

    public List<Book> getBookDataNew() {
        List<Book> books = jdbcTemplate.query("SELECT id,title,author,priceOld,price FROM books WHERE sold_count > 0 ORDER BY sold_count DESC", (ResultSet rs, int rowNum) -> {
            Book book = new Book();
            book.setId(rs.getInt("id"));
            book.setTitle(rs.getString("title"));
            book.setAuthor(rs.getString("author"));
            book.setPriceOld(rs.getString("priceOld"));
            book.setPrice(rs.getString("price"));
            return book;
        });
        return new ArrayList<>(books);
    }

    public List<Author> getAuthorData(){
        List<Author> authors = jdbcTemplate.query("SELECT * FROM authors ORDER BY author", (ResultSet rs, int rowNum) -> {
            Author author = new Author();
            author.setId(rs.getInt("id"));
            author.setAuthor(rs.getString("author"));
            return author;
        });
        return new ArrayList<>(authors);
    }
}
